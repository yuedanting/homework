$(document).ready(function(){
	aa();
	bb();
//Carouse 1
function aa(){
	var deal_space= $('.Carouse_1');
	var list =$('.list1');
	var buttons=$('.CarouseButtons span');
	var prev =$('.prev1');
	var next =$('.next1');
	var len=3;
	var interval=3000;
	var timer;
	var CurrentIndex =1;

	function animate (position){
		var left =parseInt(list.css('left')) + position;
		position='+='+position;
		list.animate({'left':position},300,'swing',function(){
			if(left>-1){
				list.css('left',-700*len);//运动结束归整数，防止越过
			}
			if(left<(-700*len)){
				list.css('left',-700);
			}
		});
	}
	function showButton() {
         buttons.eq(CurrentIndex-1).addClass('on')
         .siblings().removeClass('on');
         /*way 2   buttons.eq(CurrentIndex-1).parent().children().removeClass('on');
              	   buttons.eq(CurrentIndex-1).addClass('on'); */
     };
    function play(){ /* 递归实现自动轮播*/
    	timer =setTimeout(function(){
    		next.trigger('click');//为next添加点击事件
    		play();
    	},interval);
    };

	function stop(){/*消除定时器*/
		clearTimeout(timer);
	}
	next.click(function (){
		if(list.is(':animated'))//动画播放完毕
			{return;}//播放完毕结束click事件
		if(CurrentIndex==3)
			{CurrentIndex=1;}//对button索引的
		else
			{CurrentIndex+=1;}
		animate(-700);
		showButton();
	});
	prev.click(function(){
		if(list.is(':animated'))
			{return;}
		if(CurrentIndex==1)
			{CurrentIndex=3;}
		else
			{CurrentIndex-=1;}
		animate(700);
		showButton();
	});
	buttons.each(function(){//遍历所有button绑定点击事件操纵
		$(this).click(function(){
			if(list.is(':animated')||$(this).attr('class')=='on')
				{return;}//重复点一个点处理
			var myIndex=parseInt($(this).attr('index'))
			var position=-700*(myIndex-CurrentIndex);
			animate(position);
			CurrentIndex=myIndex;
			showButton();
		})
	})
	deal_space.hover(stop,play);
	play();
};

function bb(){
	  	var length; 
	    var currentIndex = 0;
	   	var interval; 
	   	var deal_space=$('.Carouse_2')
	    var hasStarted = false, //是否已经开始轮播 
   		t = 3000; //轮播时间间隔 
	    length = $('.slider-panel').length; 
	  //将除了第一张图片隐藏 
	  	$('.slider-panel:not(:first)').hide(); 
	  //将第一个button设为激活状态 
	  	$('.slider-item:first').addClass('on'); 
	    e = window.event || e;//对象事件参数
	    $('.slider-item').hover(function(e) { 
	         stop(); 
	              //获得激活状态的button值
	         var preIndex = $(".slider-item").filter(".on").index(); //老button激活的选中赋值
	            currentIndex = $(this).index(); //currentIndex即当前点击的this对象
	         play(preIndex, currentIndex); //转到currentIdex位置
	     },function() 
	     {  start();});
     
	    $('.prev2').unbind('click'); //移除点击事件
	 	$('.prev2').click(function(){
	 		pre();
	 	})
	    $('.next2').unbind('click'); 
	    $('.next2').click(function(){
	    	next();
	    });
	  
	  /** 
	   * 向前翻页 
	   */ 
	      function pre() { 
	       var preIndex = currentIndex; 
	       currentIndex = (--currentIndex + length) % length; 
	       play(preIndex, currentIndex); 
	      } 
	  /** 
	   * 向后翻页 
	   */ 
	      function next() { 
	       var preIndex = currentIndex; 
	       currentIndex = ++currentIndex % length; 
	       play(preIndex, currentIndex); 
	      } 
	  /** 
	   * 从preIndex页翻到currentIndex页 
	   * preIndex 整数，翻页的起始页 
	   * currentIndex 整数，翻到的那页 
	   */ 
	      function play(preIndex, currentIndex) { 
	       $('.slider-panel').eq(preIndex).fadeOut(500) //选中preIdex位置的图，fadeout隐藏0.5s内
	        .parent().children().eq(currentIndex).fadeIn(1000); //.slider-panel父元素的所有子元素==currentIndex显示
	       $('.slider-item').removeClass('on'); //移除所有button效果
	       $('.slider-item').eq(currentIndex).addClass('on'); //添加当前效果
	      } 
	  /** 
	   * 开始轮播 
	   */ 
	      function start() { 
	       if(!hasStarted) { 
	        hasStarted = true; 
	        interval = setInterval(next, t); 
	       } 
	      } 
	      /** 
	       * 停止轮播 
	       */ 
	      function stop() { 
	       clearInterval(interval); 
	       hasStarted = false; 
	      } 

	      deal_space.hover(stop,start);
	      //开始轮播 
	      start(); 
};

});