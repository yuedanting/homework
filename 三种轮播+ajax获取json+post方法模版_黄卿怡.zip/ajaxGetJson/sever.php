<?php
	//告诉浏览器是什么格式
	header("charset=utf-8");
	header("Content-Type:text/html;charset=utf-8");
	//告诉浏览器不要缓存数据
	header("Cache-Contro l:no-cache");
	//接受数据
	$username=$_POST['username'];

	//如何处理格式
	$info="";

	if($username=="黄卿怡"||$username=="岳丹婷"){
		//$info json 数据格式字串
		$info='{"res":"该用户是管理员"}';//只能以字串返回
	}else{
		$info='{"res":"该用户是游客"}';
	}
	echo $info;

?>